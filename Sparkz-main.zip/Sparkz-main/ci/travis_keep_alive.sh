#!/bin/bash

bash -c 'while true; do sleep 300; echo "______ travis keep alive ______"; done &'