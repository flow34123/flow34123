Hybrid Proof-of-Work/Proof-of-Stake consensus protocol implementation
======================================================================

