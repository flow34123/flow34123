package sparkz.util.encode

class Base64Specification extends BytesEncoderSpecification {
  override val encoder: BytesEncoder = Base64
}
