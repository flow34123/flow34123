package sparkz.core.utils

object SerializationConstants {
  val IntSize: Int = 4
  val LongSize: Int = 8
}
